package edu.io;

public class Main {
    public static void main(String[] args) {
        System.out.println("Gold Rush");
    }
}
